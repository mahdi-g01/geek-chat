import * as React from "react"

import { cn } from "@/lib/utils"

function Input({ className, type, ...props }: React.ComponentProps<"input">) {
  return (
    <input
      type={type}
      data-slot="input"
      className={cn(
        "bg-neutral-100 text-card-foreground border-border border !py-5 hover:bg-card/40",
        "file:text-card-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 h-9 w-full min-w-0 rounded-md px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
        "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]",
        "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
        className
      )}
      {...props}
    />
  )
}

function LabeledInput({ label, containerClassName, ...props }:
                          React.ComponentProps<"input"> & {label: string, containerClassName?: string}) {
  return (
      <div className={`flex flex-col gap-1 ${containerClassName}`}>
          <label htmlFor={props.id} className={"w-full text-sm text-muted-foreground"}>
              {label}
          </label>
          <Input {...props}/>
      </div>
  )
}

export { Input, LabeledInput }
